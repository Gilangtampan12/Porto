document.addEventListener("DOMContentLoaded", () => {
  const ratings = document.querySelectorAll(".rating");

  ratings.forEach((rating) => {
    const rate = rating.getAttribute("data-rate");
    rating.style.width = `${rate}%`;
  });
});
document.addEventListener('DOMContentLoaded', function() {
  const sidebar = document.querySelector('.sidebar');
  const mainContent = document.querySelector('.main-content');
  const sidebarToggle = document.getElementById('sidebarToggle');

  // Toggle sidebar visibility on click of the hamburger menu
  sidebarToggle.addEventListener('click', function() {
    sidebar.classList.toggle('show');
    mainContent.classList.toggle('active');
  });
});
